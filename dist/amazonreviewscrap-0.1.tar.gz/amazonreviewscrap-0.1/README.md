# amazon-review-scrapper
### Prerequisite:
Tested Python version 3.7

Install requirements.txt file

Create two folder in root directory
1. html
2. csv

## First run selenium_date_download.py 
It will open browser and download page source code in html folder

## Second run scrap_data.py
It will gather all downloaded source code and scrap data through bs4 after that 
store data in a csv file